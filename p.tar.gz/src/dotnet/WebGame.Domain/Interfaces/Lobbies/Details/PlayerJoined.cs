﻿namespace WebGame.Domain.Interfaces.Lobbies.Details;

public record PlayerJoined(Guid PlayerId, string PlayerName);