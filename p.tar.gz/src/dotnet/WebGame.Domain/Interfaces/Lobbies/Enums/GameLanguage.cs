﻿namespace WebGame.Domain.Interfaces.Lobbies.Enums;

public enum GameLanguage
{
    English,
    Polish
}