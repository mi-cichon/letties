﻿namespace WebGame.Domain.Interfaces.Lobbies.Enums;

public enum GameLobbyState
{
    Lobby = 0,
    Game = 100,
    PostGame = 200
}