﻿namespace WebGame.Domain.Interfaces.Lobbies.Enums;

public enum BoardType
{
    Classic = 0,
    Arena = 1,
    Wildlands = 2,
    Widelands = 3
}