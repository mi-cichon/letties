﻿namespace WebGame.Domain.Interfaces.Bots;

public enum BotDifficulty
{
    Easy,
    Medium,
    Hard
}