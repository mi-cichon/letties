﻿namespace WebGame.Domain.Interfaces.Games.MoveCalculations;

public record ScannedWord(string Text, int Points, bool IsHorizontal);