export * from './gameHub.service';
import { GameHubService } from './gameHub.service';
export * from './loginHub.service';
import { LoginHubService } from './loginHub.service';
export const APIS = [GameHubService, LoginHubService];
